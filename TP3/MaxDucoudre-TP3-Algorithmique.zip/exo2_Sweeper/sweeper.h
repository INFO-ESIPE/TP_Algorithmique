#ifndef SWEEPER_H
#define SWEEPER_H


/*Lance le démineur*/
int start_sweeper(int debug_mode);

#endif /* DRAW_H */