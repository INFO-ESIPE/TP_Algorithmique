# TP04 - Algorithmique Tri
## Max Ducoudré

## Compilation 
`make tp04` pour créer un executable `tp04` permettant de tester les algoritmes de tri
`make demo1` pour créer un executable `demo1` permettant d'avoir une démonstration du tri par séléction
`make demo2` pour créer un executable `demo2` permettant d'avoir une démonstration du tri fusion
`make clean` pour retirer tous les fichiers compilés

## Données
Le répertoire `data` contient toutes les données permettant de générer les graphiques
Exemple : `evince data/sort1.ps` pour afficher le graphique sur les nombres de comparaisons




